package com.example.cropadv;
import android.app.Application;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.*;
public class globalVar extends Application {
    private Socket sockobj;
    BufferedReader reader;
    /*public void create_inbuf() {
        try{
            reader = new BufferedReader(new InputStreamReader(sockobj.getInputStream()));
    }
        catch(Exception e){

        }
    }
    public BufferedReader getinbuf(){
        return reader;
    }*/
    public Socket getSockobj() {
        return sockobj;
    }
    public void setsockobj(Socket obj) {
        sockobj=obj;
    }
}

package com.example.cropadv;


import androidx.appcompat.app.AppCompatActivity;
import android.annotation.SuppressLint;
//import android.app.Notiﬁcation;
//import android.app.NotiﬁcationManager;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;
import android.view.View;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.text.TextUtils;
//import com.email.durgesh.Email;

//import javax.mail.*;
//import javax.mail.internet.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Properties; import java.util.*;
import static android.widget.Toast.LENGTH_LONG;
public class user extends AppCompatActivity  {
    private Button btn1, btn11;
    private EditText ent1, ent2;
    DatabaseHelper dh;
    Boolean EditTextEmptyHolder;
    SQLiteDatabase sqLiteDatabaseObj;
    Cursor cursor;
    String TempPassword = "NOT_FOUND";
    String Tempname = "null";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user);
        btn1 = (Button) findViewById(R.id.button1);
        btn11 = (Button) findViewById(R.id.button11);
        ent1 = (EditText) findViewById(R.id.editText3);
        String msg = ent1.getText().toString();
        ent2 = (EditText) findViewById(R.id.editText4);
        dh = new DatabaseHelper(this);


        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CheckEditTextStatus();
                LoginFunction();
                //Intent i2 = new Intent(user.this, initSocket.class);
                //startActivity(i2);

            }
        });
        btn11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i1 = new Intent(user.this, user_reg.class);
                startActivity(i1);

            }
        });


    }
    class Thread3 implements Runnable {
        private String message;
        Thread3(String message) {
            this.message = message;
        }
        @Override
        public void run() {
            final globalVar shared_obj = (globalVar) getApplicationContext();
            Socket obj=shared_obj.getSockobj();
            try{
                PrintWriter output=new PrintWriter(obj.getOutputStream());
                output.write(message);
                output.flush();
            }
            catch (IOException e){
                Toast toast=Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_LONG);
                toast.show();
            }
            //Toast toast=Toast.makeText(getApplicationContext(), message, Toast.LENGTH_LONG);
            //toast.show();
            //output.write(message);
            //output.flush();*/
            //recv_obj= new Thread(new recv());
            //recv_obj.start();
            /*runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    result.setText("[SUCCESS]\nRequest send successfully...");
                }
            });*/
        }
    }
    @Override
    protected void onDestroy() {
        //recv_obj_flag=1;
        Thread send_obj= new Thread(new Thread3("quit"));
        send_obj.start();
        super.onDestroy();
        Toast toast=Toast.makeText(getApplicationContext(), "CropAdv Closed", Toast.LENGTH_LONG);
        toast.show();

    }


    public void LoginFunction() {
        if (EditTextEmptyHolder) {

            // Opening SQLite database write permission.
            sqLiteDatabaseObj = dh.getWritableDatabase();
            // Adding search email query to cursor.
            cursor = sqLiteDatabaseObj.query(dh.TABLE_NAME, null, " " + dh.Col1 + "=?", new String[]{ent1.getText().toString()}, null, null, null);
            while (cursor.moveToNext()) {
                if (cursor.isFirst()) {
                    cursor.moveToFirst();
                    // Storing Password associated with entered email.
                    TempPassword = cursor.getString(cursor.getColumnIndex(dh.Col2));
                    Tempname = cursor.getString(cursor.getColumnIndex(dh.Col1));
                    Log.d("pswd", TempPassword);                        // Closing cursor.
                    cursor.close();
                }
            }
            // Calling method to check ﬁnal result ..
            CheckFinalResult();
        } else {
            //If any of login EditText empty then this block will be executed.
            Toast.makeText(user.this, "Please Enter UserName or Password.", LENGTH_LONG).show();
        }

    }

    // Checking EditText is empty or not.
    public void CheckEditTextStatus() {
        // Getting value from All EditText and storing into String Variables.
        // Checking EditText is empty or no using TextUtils.
        if (TextUtils.isEmpty(ent1.getText().toString()) || TextUtils.isEmpty(ent2.getText().toString())) {
            EditTextEmptyHolder = false;
        } else {
            EditTextEmptyHolder = true;
        }
    }


    // Checking entered password from SQLite database email associated password.
    public void CheckFinalResult() {
        //Log.d("pswd", TempPassword);
        //Log.i("pswd", TempPassword);
        if (TempPassword.equalsIgnoreCase(ent2.getText().toString()) && Tempname.equalsIgnoreCase(ent1.getText().toString())) {
            Toast.makeText(user.this, "Login Successfully", LENGTH_LONG).show();            //Toast.makeText(getApplicationContext(),"Email was sent successfully ",2000).show();
            // Going to Dashboard activity after login success message.
            //Intent intent = new Intent(this, first_page.class);
            //Intent intent1 = new Intent(User.this, Unsolved.class).putExtra("userid",ent1.getText().toString());            //Intent intent1 = new Intent(User.this, Viewproﬁle.class).putExtra("userid",ent1.getText().toString());            //Intent intent2 = new Intent(User.this, Usercomplaint.class).putExtra("userid",ent1.getText().toString());
            // Sending Email to Dashboard Activity using intent
            //startActivity(intent);
            Intent i2 = new Intent(user.this, initSocket.class);
            startActivity(i2);
        } else {
            Toast.makeText(user.this, "UserName or Password is Wrong, Please Try Again.", LENGTH_LONG).show();
        }
        TempPassword = "NOT_FOUND";
    }

}
   /* @Override
    public void onClick(View view) {
        if (view == btn1){
        LoginFunction();
        }
    }
*/
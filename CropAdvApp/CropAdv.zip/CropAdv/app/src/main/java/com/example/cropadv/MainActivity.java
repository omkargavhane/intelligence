package com.example.cropadv;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import java.io.*;
import android.os.Bundle;
import android.widget.*;
//import android.widget.Toast;

//import java.net.*;
//import java.io.*;

import android.annotation.SuppressLint;
//import android.os.Bundle;
//import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.io.DataInputStream;
import java.io.BufferedInputStream;
import java.util.Scanner;

@SuppressLint("SetTextI18n")
public class MainActivity extends AppCompatActivity {
    Thread recv_obj = null;
    Thread send_obj = null;
    EditText etIP, etPort;
    TextView result;
    EditText dn;
    //String dn_str;
    EditText sn;
    //String sn_str;
    Button fbc;
    Button reset;
    String SERVER_IP;
    int SERVER_PORT;
    PrintWriter output;
    DataInputStream input;
    //int recv_obj_flag=0;
    //int send_obj_flag=0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //etIP = "192.168.43.138";
        //etPort = 5000
        dn  = (EditText) findViewById(R.id.dn);
        //dn_str=dn.getText().toString();
        sn = (EditText) findViewById(R.id.sn);
        //sn_str=sn.getText().toString();
        result = (TextView) findViewById(R.id.tvResult);
        fbc = (Button)findViewById(R.id.buttonSubmit);
        reset = (Button)findViewById(R.id.buttonReset);
        //SERVER_IP="192.168.43.138";
        //SERVER_PORT=6000;
        recv_obj= new Thread(new recv());
        //recv_obj.start();
        Toast toast=Toast.makeText(getApplicationContext(), "Explorer...", Toast.LENGTH_LONG);
        toast.show();
        /*fbc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tvMessages.setText("");
                //SERVER_IP = etIP.getText().toString().trim();
                //SERVER_PORT = Integer.parseInt(etPort.getText().toString().trim());
                SERVER_IP="192.168.2.7";
                SERVER_PORT=5000;
                Thread1 = new Thread(new Thread1());
                Thread1.start();
            }
        });*/
        fbc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String dn_str = dn.getText().toString().trim();
                String sn_str=sn.getText().toString().trim();
                Toast toast=Toast.makeText(getApplicationContext(), "<fbc>"+dn_str+"_"+sn_str, Toast.LENGTH_LONG);
                toast.show();
                //if(!dn_str.isEmpty() && !sn_str.isEmpty()) {
                send_obj= new Thread(new Thread3("fbc"+" "+dn_str+" "+sn_str));
                send_obj.start();

                //}
                //else{
                 //   result.setText("[WARNING]\nProvide values for both DistrictName & SeasonName!!!");
                //}
            }
        });
        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dn.setText("");
                sn.setText("");
                result.setText("");
                dn.requestFocus();
            }
        });
    }
    @Override
    protected void onDestroy() {
        //recv_obj_flag=1;

        super.onDestroy();
        Toast toast=Toast.makeText(getApplicationContext(), "Home", Toast.LENGTH_LONG);
        toast.show();

    }

    /*private PrintWriter output;
    private BufferedReader input;
    class Thread1 implements Runnable {
        public void run() {
            //Socket socket;
            try {
                socket = new Socket(SERVER_IP, SERVER_PORT);
                output = new PrintWriter(socket.getOutputStream());
                //input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        result.setText("[SUCCESS]\nConnected to\nIP-ADDR:"+SERVER_IP+"\nPORT-ADDR:"+SERVER_PORT);
                    }
                });
                new Thread(new Thread2()).start();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }*/
    class recv implements Runnable {
        @Override
        public void run() {

            /*BufferedReader reader;
            try {
                reader = new BufferedReader(new InputStreamReader(shared_obj.getSockobj().getInputStream()));
            }
            catch (Exception e){

            }*/
            //BufferedReader reader=shared_obj.getinbuf();
            //while (true) {
             //   if(recv_obj_flag==1) {
              //      break;
               // }
                try {
                    final String res;
                    String t="";
                    //DataInputStream in = new DataInputStream(new BufferedInputStream(socket.getInputStream()));
                    //final byte[] res=new byte[256];
                    /*Scanner in=new Scanner(socket.getInputStream());
                    while(true) {
                        t=in.nextLine();
                        if(t==null)
                            break;
                        res+=t;
                    }*/

                    //Socket obj=shared_obj.getopbuf();
                    globalVar shared_obj = (globalVar)getApplicationContext();
                    Integer nol=Integer.parseInt(shared_obj.reader.readLine());
                    int cnt=0;
                    while(true){
                        if(cnt==nol)
                            break;
                        t+=shared_obj.reader.readLine()+"\n";
                        cnt+=1;

                    }
                    //}
                    //result.setText(res);
                    //input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                    //DataInputStream dis=new DataInputStream(socket.getInputStream());
                    //int count= dis.read(res);
                    //final String res=in.readUTF();
                    res=t;
                    //result.setText(res);
                    if(res!=null) {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                result.setText(res);
                            }
                        });
                    }
                    //else {
                    //    Thread1 = new Thread(new Thread1());
                    //    Thread1.start();
                    //    return;
                    //}
                } catch (Exception e) {
                    Toast toast=Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_LONG);
                    toast.show();
                    e.printStackTrace();
                }
            //}
        }
    }
    class Thread3 implements Runnable {
        private String message;
        Thread3(String message) {
            this.message = message;
        }
        @Override
        public void run() {
            final globalVar shared_obj = (globalVar) getApplicationContext();
            Socket obj=shared_obj.getSockobj();
            try{
                output=new PrintWriter(obj.getOutputStream());
                output.write(message);
                output.flush();
                recv_obj.start();
            }
            catch (IOException e){
                Toast toast=Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_LONG);
                toast.show();
            }
            //Toast toast=Toast.makeText(getApplicationContext(), message, Toast.LENGTH_LONG);
            //toast.show();
            //output.write(message);
            //output.flush();*/
            //recv_obj= new Thread(new recv());
            //recv_obj.start();
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
            result.setText("[SUCCESS]\nRequest send successfully...");
                }
            });
        }
    }

}
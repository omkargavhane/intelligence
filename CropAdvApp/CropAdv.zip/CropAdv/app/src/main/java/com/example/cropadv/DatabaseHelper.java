package com.example.cropadv;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import java.io.FileInputStream; import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
public class DatabaseHelper extends SQLiteOpenHelper {
    public static final String DATABASE_NAME = "User.db";
    public static final String TABLE_NAME = "user_info";
    public static final String Col1 = "user_id";
    public static final String Col2 = "password";
    public static final String Col3 = "Contact";
    public static final String sql1 = "Create table if not exists " + TABLE_NAME + "(user_no INTEGER PRIMARY KEY AUTOINCREMENT ,user_id VARCHAR (20)UNIQUE,password Varchar(20), Contact Varchar(10)  )";

    // public static ﬁnal String[] statements = new String[]{sql1, sql2};
    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(sql1);
        //  db.execSQL(sql2);
        // db.execSQL(sql5);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
    }/*    public void insertimage(String email,byte[] imgbyte,String Date,String Time){
    SQLiteDatabase db =this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(imagetable,email);
        cv.put(imagetable1,imgbyte);
        cv.put(imagetable2,Date);
        cv.put(imagetable3,Time);
        db.insert(TABLE_NAME4,null,cv);
    }    public byte[] retreiveImageFromDB(String email) {
    String email1=email;
    SQLiteDatabase db =this.getWritableDatabase();
    Date d=new Date();
    SimpleDateFormat sdf=new SimpleDateFormat("hh:mm a");
    String time = sdf.format(d);
    Calendar c = Calendar.getInstance();
    String date = DateFormat.getDateInstance().format(c.getTime());
    Cursor cursor1 = db.rawQuery("SELECT image FROM "+ TABLE_NAME4 +" WHERE EmailID = '"+email1+"' AND Date = '"+date+"'", null);        Cursor cursor = db.rawQuery("SELECT image FROM "+ TABLE_NAME2 +" WHERE EmailID = '"+email1+"'", null);            if (cursor.moveToFirst()) {            byte[] blob = cursor.getBlob(cursor.getColumnIndex(imagetable1));            cursor.close();
        return blob;
    }
        cursor.close();
    return null;
}*/

    public boolean insertData(String userid1, String pswd, String contact) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(Col1, userid1);
        contentValues.put(Col2, pswd);
        contentValues.put(Col3, contact);
        long result = db.insert(TABLE_NAME, null, contentValues);
        if (result == -1) {
            return false;
        } else {
            return true;
        }
    }
}
    /*public  boolean transfer( String emailid, String title, String complaint,String Date,byte[] img) {
    SQLiteDatabase db = this.getWritableDatabase();
    ContentValues contentValues = new ContentValues();
    contentValues.put(solvedcomplaint2, emailid);
    contentValues.put(solvedcomplaint3, title);
    contentValues.put(solvedcomplaint4, complaint);
    contentValues.put(solvedcomplaint5, Date);
    contentValues.put(solvedcomplaint6,img);
    long result = db.insert(TABLE_NAME3, null, contentValues);
    if (result == -1) {
        return false;
    } else {
        return true;
    }
}        public boolean updateData(String email, String title, String complaint, String date, String time, String Status){
    SQLiteDatabase db = this.getWritableDatabase();
    ContentValues contentValues = new ContentValues();
    contentValues.put(complaint2,email);
    contentValues.put(complaint3,title);
    contentValues.put(complaint4,complaint);
    contentValues.put(complaint5,date);
    contentValues.put(complaint6,time);
    contentValues.put(complaint7,Status);
    db.update(TABLE_NAME2,contentValues,"Status=?",new String[] {Status});
    return true;
}
    public boolean logindata(String user_id, String password){
    SQLiteDatabase db = this.getWritableDatabase();
    ContentValues contentValues = new ContentValues();
        contentValues.put(LOGIN1,user_id);
        contentValues.put(PSWD,password);
        long result=db.insert(TABLE_NAME1,null,contentValues);
        if(result==-1){
            return false;
        }        else{            return true;        }
}    public boolean insertcomplaint(String email,String title,String complaint,String date,String time,byte[] image)
    {        SQLiteDatabase db = this.getWritableDatabase();
    ContentValues contentValues = new ContentValues();
    contentValues.put(complaint2,email);
    contentValues.put(complaint3,title);
    contentValues.put(complaint4,complaint);
    contentValues.put(complaint5,date);
    contentValues.put(complaint6,time);
    contentValues.put(complaint8,image);
    long result=db.insert(TABLE_NAME2,null,contentValues);
    if(result==-1){            return false;        }
    else{            return true;        }
    }
    public Cursor GetUsers(){
    Date d=new Date();
    SimpleDateFormat sdf=new SimpleDateFormat("hh:mm a");
    String time = sdf.format(d);
    Calendar c = Calendar.getInstance();
    String date = DateFormat.getDateInstance().format(c.getTime());
    SQLiteDatabase db = this.getWritableDatabase();
    Cursor cursor = db.rawQuery("SELECT Emailid,Title,Complaint,Date,image FROM "+ TABLE_NAME2 +" WHERE TRIM(Date) = '"+date.trim()+"'", null);
        if(cursor!= null){
            cursor.moveToFirst();
        }
        else{
            Log.i("Error","no");
        }
        return cursor;
}    public Cursor GetUsers1(){
        SQLiteDatabase db = this.getWritableDatabase();
        String status="no";
        Cursor cursor = db.rawQuery("SELECT Emailid,Title,Complaint,Date,image FROM "+ TABLE_NAME2 +" WHERE Status = '"+status+"'", null);
        if(cursor!= null){
            cursor.moveToFirst();
        }
        else{
            Log.i("Error","no");
        }
        return cursor;
}    public Cursor GetUsers2(){
        SQLiteDatabase db = this.getWritableDatabase();
        String status="Yes";
        Cursor cursor = db.rawQuery("SELECT Emailid,Title,Complaint,Date,image FROM "+ TABLE_NAME3, null);
        if(cursor!= null){
            cursor.moveToFirst();
        }
        else{            Log.i("Error","no");
        }
        return cursor;
}    public Integer deleteData(String emailid,String title,String Complaint)
    {        SQLiteDatabase db =this.getWritableDatabase();
    return db.delete(TABLE_NAME2,"Emailid = ? and Title = ? and Complaint = ?", new String[] {emailid,title,Complaint});
    }
    // Get User Details based on userid    /*    public ArrayList<HashMap<String, String>> GetUserByUserId(int userid){        SQLiteDatabase db = this.getWritableDatabase();        ArrayList<HashMap<String, String>> userList = new ArrayList<>();        String query = "SELECT name, location, designation FROM "+ TABLE_Users;        Cursor cursor = db.query(TABLE_Users, new String[]{KEY_NAME, KEY_LOC, KEY_DESG}, KEY_ID+ "=?",new String[]{String.valueOf(userid)},null, null, null, null);        if (cursor.moveToNext()){            HashMap<String,String> user = new HashMap<>();            user.put("name",cursor.getString(cursor.getColumnIndex(KEY_NAME)));            user.put("designation",cursor.getString(cursor.getColumnIndex(KEY_DESG)));            user.put("location",cursor.getString(cursor.getColumnIndex(KEY_LOC)));            userList.add(user);        }        return  userList;    }*/    // Delete User Details    public Integer DeleteUser(String emailid){        SQLiteDatabase db = this.getWritableDatabase();        return db.delete(TABLE_NAME,COL3+" =?",new String[]{String.valueOf(emailid)});        //db.delete(TABLE_NAME1,LOGIN1+" =?",new String[]{String.valueOf(emailid)});        //c=db.delete(TABLE_NAME2, complaint2+" = ?",new String[]{String.valueOf(emailid)});
// Update User Details    public int UpdateUserDetails(String pswd,  String emailid){        SQLiteDatabase db = this.getWritableDatabase();
   /* ContentValues cVals = new ContentValues();
    cVals.put(PSWD,pswd);
    int count = db.update(TABLE_NAME1, cVals, LOGIN1+" = ?",new String[]{String.valueOf(emailid)});
return  count;    }
public Cursor show_user(){
        SQLiteDatabase db=this.getWritableDatabase();
        Cursor c=db.rawQuery("select Name,Building_No from "+TABLE_NAME,null);
        if(c!= null){
            c.moveToFirst();
        }
        else{
            Log.i("Error","no");
        }
        return c;
        }
        }*/
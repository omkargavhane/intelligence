package com.example.cropadv;

import android.os.Bundle;
import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;

import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class wikiSearch extends AppCompatActivity {
    EditText search;
    Button wikibut;
    String search_str;
    PrintWriter output;
    TextView result;
    Thread recv_obj;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.wiki);
        search=(EditText) findViewById(R.id.wiki);
        wikibut=(Button) findViewById(R.id.wikibutton);
        result=(TextView)findViewById(R.id.wikires);
        result.setMovementMethod(new ScrollingMovementMethod());
        recv_obj= new Thread(new recv());
        //recv_obj.start();
        Toast toast=Toast.makeText(getApplicationContext(), "Wikisearch", Toast.LENGTH_LONG);
        toast.show();
        wikibut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                search_str = search.getText().toString().trim();
                Toast toast=Toast.makeText(getApplicationContext(), "<ws>"+search_str, Toast.LENGTH_LONG);
                toast.show();
                //if(!dn_str.isEmpty() && !sn_str.isEmpty()) {
                new Thread(new Thread3("ws"+" "+search_str)).start();
                //}
                //else{
                //   result.setText("[WARNING]\nProvide values for both DistrictName & SeasonName!!!");
                //}
            }
        });
    }
    @Override
    protected void onDestroy() {
        //recv_obj_flag=1;
        super.onDestroy();
        Toast toast=Toast.makeText(getApplicationContext(), "Home", Toast.LENGTH_LONG);
        toast.show();

    }


    class recv implements Runnable {

        @Override
        public void run() {

           // BufferedReader reader=shared_obj.getinbuf();
            //while (true) {
                try {
                    final String res;
                    String t="";
                    //DataInputStream in = new DataInputStream(new BufferedInputStream(socket.getInputStream()));
                    //final byte[] res=new byte[256];
                    /*Scanner in=new Scanner(socket.getInputStream());
                    while(true) {
                        t=in.nextLine();
                        if(t==null)
                            break;
                        res+=t;
                    }*/
                    globalVar shared_obj = (globalVar) getApplicationContext();
                    //Socket obj = shared_obj.getSockobj();
                    //BufferedReader reader = new BufferedReader(new InputStreamReader(obj.getInputStream()));
                    /*Integer nol=Integer.parseInt(reader.readLine());
                    int cnt=0;
                    while(true){
                        if(cnt==nol)
                            break;
                        t+=reader.readLine()+"\n";
                        cnt+=1;

                    }*/
                    //}
                    //result.setText(res);
                    //input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                    //DataInputStream dis=new DataInputStream(socket.getInputStream());
                    //int count= dis.read(res);
                    //final String res=in.readUTF();
                    /*Integer nol=Integer.parseInt(reader.readLine());
                    int cnt=0;
                    while(true){
                        if(cnt==nol)
                            break;
                        t+=reader.readLine()+"\n";
                        cnt+=1;

                    }*/
                    t=shared_obj.reader.readLine();
                    res=t;
                    if(res!=null) {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                result.setText(res);
                            }
                        });
                    }
                    //else {
                    //    Thread1 = new Thread(new Thread1());
                    //    Thread1.start();
                    //    return;
                    //}
                } catch (Exception e) {
                    Toast toast=Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_LONG);
                    toast.show();
                    e.printStackTrace();
                }
            //}
        }
    }
    class Thread3 implements Runnable {
        private String message;
        Thread3(String message) {
            this.message = message;
        }
        @Override
        public void run() {
            final globalVar shared_obj = (globalVar) getApplicationContext();
            Socket obj=shared_obj.getSockobj();
            try{
                output=new PrintWriter(obj.getOutputStream());
                output.write(message);
                output.flush();
                recv_obj.start();
            }
            catch (IOException e){
                Toast toast=Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_LONG);
                toast.show();
            }
            //Toast toast=Toast.makeText(getApplicationContext(), message, Toast.LENGTH_LONG);
            //toast.show();
            //output.write(message);
            //output.flush();*/
            //recv_obj= new Thread(new recv());
            //recv_obj.start();
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    result.setText("[SUCCESS]\nRequest send successfully...");
                }
            });
        }
    }
}
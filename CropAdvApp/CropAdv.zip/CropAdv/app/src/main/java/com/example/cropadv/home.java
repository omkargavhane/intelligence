package com.example.cropadv;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class home extends AppCompatActivity {
    Button explore,wiki,top10,camera,geo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.crop_home);
        explore =findViewById(R.id.explore);
        wiki=findViewById(R.id.wiki);
        top10=findViewById(R.id.Top10);
        camera=findViewById(R.id.camera);
        geo=findViewById(R.id.geolocation);
        explore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(home.this, MainActivity.class);
                startActivity(intent);
            }
        });
        wiki.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(home.this, wikiSearch.class);
                startActivity(intent);
            }
        });
        top10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(home.this, top10.class);
                startActivity(intent);
            }
        });
        camera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(home.this, camera.class);
                startActivity(intent);
            }
        });
        geo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(home.this, MapsActivity.class);
                startActivity(intent);
            }
        });
    }

}

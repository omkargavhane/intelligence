package com.example.cropadv;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
public class user_reg extends AppCompatActivity {
    Button bt;
    EditText user_id,password,contact;
    DatabaseHelper dh;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_reg);
        dh= new DatabaseHelper(this);
        user_id=(EditText)findViewById(R.id.id1);
        password=(EditText)findViewById(R.id.id2);

        contact=(EditText)findViewById(R.id.id3);

        bt=(Button)findViewById(R.id.button1);
        add();
    }
    public void add() {
        bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (TextUtils.isEmpty(user_id.getText().toString()) ||
                        TextUtils.isEmpty(password.getText().toString()) ||
                        TextUtils.isEmpty(contact.getText().toString())) {
                    Toast.makeText(user_reg.this, "please fill all the details", Toast.LENGTH_LONG).show();
                } else {
                    boolean is1 = dh.insertData(user_id.getText().toString(), password.getText().toString(), contact.getText().toString());
                    //boolean is2 = dh.logindata(user_id.getText().toString(), password.getText().toString());
                    if (is1 == true) {
                        Toast.makeText(user_reg.this, "Data inserted", Toast.LENGTH_LONG).show();
                        //Intent i = new Intent();
                        //startActivity(i);
                    } else {
                        Toast.makeText(user_reg.this, "Data not inserted", Toast.LENGTH_LONG).show();
                    }
                    /*if (is2 == true) {
                        Toast.makeText(user_reg.this, "Registered", Toast.LENGTH_LONG).show();
                    } else {
                        Toast.makeText(user_reg.this, "Cant Registered", Toast.LENGTH_LONG).show();
                    }*/
                }
                dh.close();
                            }
        });

    }
}


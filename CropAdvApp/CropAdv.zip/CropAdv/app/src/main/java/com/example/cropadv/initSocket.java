package com.example.cropadv;

import android.os.Bundle;
import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.io.Serializable;
import java.net.Socket;
import java.io.DataOutputStream;
import android.widget.Toast;



public class initSocket extends AppCompatActivity{
    Button sockbut;
    EditText ipaddr_et;
    //int port = 6000;
    Thread create_sock_obj;
    String   str_ipaddr;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.init_socket);
        ipaddr_et= (EditText)findViewById(R.id.ipaddr);

        sockbut = findViewById(R.id.sockbut);
        sockbut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                /*try{
                create_sock_obj.join(5000);}
                catch(InterruptedException e){
                    Toast toast = Toast.makeText(getApplicationContext(),
                            e.toString(),
                            Toast.LENGTH_LONG);
                    toast.show();
                }
                try{
                Thread.sleep(5000);}
                catch (InterruptedException e){
                    Toast toast = Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_LONG);
                    toast.show();
                }*/
                str_ipaddr = ipaddr_et.getText().toString().trim();
                Toast.makeText(initSocket.this,str_ipaddr, Toast.LENGTH_SHORT).show();
                create_sock_obj=new Thread(new create_sock());
                create_sock_obj.start();
                //Toast.makeText(initSocket.this,"connected", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(initSocket.this, home.class);
                startActivity(intent);
            }
        });
    }
    class create_sock implements Runnable
    {
        public void run() {
            try {
                globalVar shared_obj = (globalVar) getApplicationContext();
                Socket obj = new Socket(str_ipaddr, 7000);
                shared_obj.setsockobj(obj);
                shared_obj.reader=new BufferedReader(new InputStreamReader(shared_obj.getSockobj().getInputStream()));
                //share_socket_obj.out = new DataOutputStream(share_socket_obj.sockobj.getOutputStream());
                //share_socket_obj.oos = new ObjectOutputStream(share_socket_obj.sockobj.getOutputStream());
                /*share_writer_obj.output = new PrintWriter(sockobj.getOutputStream());
                InputStreamReader streamReader= new InputStreamReader(sockobj.getInputStream());
                share_writer_obj.reader= new BufferedReader(streamReader);
                Toast toast = Toast.makeText(getApplicationContext(),
                        "Connected :-)",
                        Toast.LENGTH_LONG);
                toast.show();*/

            } catch (IOException e) {
                e.printStackTrace();
                Toast toast = Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_LONG);
                toast.show();
            }
        }

    }
}
/*

*/
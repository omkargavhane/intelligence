from googletrans import Translator
import wikipedia
def wiki_search(query):
    translator = Translator()
    summary = wikipedia.summary(query)
    trans = translator.translate(summary, dest='mr')
    return trans.text

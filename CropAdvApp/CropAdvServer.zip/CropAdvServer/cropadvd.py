from crop_advisor import *
import socket
import threading
from wiki_search import *
from top_ten import *
fp=open("crop.csv","r")
dn,sn=get_knowns(fp)
template='[BEST CROPS]\n'+'-'*35+'\n|season |crop   |p/a  |\n'+'-'*35+'\n'
obj=socket.socket()
obj.bind(("0.0.0.0",7000))
def cropd():
    obj.listen(1)
    conn,addr=obj.accept()
    print("Got connection from ->",addr)
    th=threading.Thread(target=cropd)
    th.start()
    while True:
        res=''
        req=conn.recv(2048).decode()
        req=req.split(" ")
        if req[0]=="fbc":
            req_dn,req_sn=req[1],req[2]
            req_dn,req_sn=req_dn.lower(),req_sn.lower()
            print(addr,'[find best crops]',req_dn,req_sn)
            if req_dn.upper() not in dn or req_sn not in \
            ['autumn','summer','rabi','whole year','kharif','winter']:
                res='2\n'+'[ERROR]\n'+'Value not found in storage!!!\n'
                conn.sendall(res.encode())
            else:
                header='-'*35+'\n[CropAdv]\n'+'-'*35+'\nDistrict Name ->'+req_dn+'.\n'+'Season Name '
                header+='->'+req_sn+'.\n'
                res_list=get_bestcrop(req_dn,req_sn)
                for each in res_list:
                    for k,v in each.items():
                        res+='|'+k+'|'+v[0]+'|'+str(round(v[1],3))+'|\n'
                    if k==req_sn:prediction=v
                    if k=='whole year':whole_year=v
                if prediction[1]<whole_year[1]:prediction=whole_year
                res+='-'*35+'\n[PREDICTION]::Advisable crop is::\n'+prediction[0]+'\n'
                res+='-'*35+'\n'
                #print(header+template+res)
                res='19\n'+header+template+res
                conn.sendall(res.encode())
                print(addr,"find best crops req served")
        elif req[0]=='ws':
            print(addr,'[wikisearch]',' '.join(req[1:]))
            try:
                res=wiki_search(' '.join(req[1:]))+'\n'
            except:
                res='oops!!! We didnt find.Try something else.'
                conn.sendall(res.encode())
            #print(res)
            conn.sendall(res.encode())
            print(addr,"wikisearch req served")
        elif req[0]=='top10':
            print(addr,'[Top10]',' '.join(req[1:]))
            try:
                res='10\n'+top_ten(' '.join(req[1:]))
            except:
                res='oops!!! We didnt find.Try something else.'
                conn.sendall(res.encode())
            #print(res)
            conn.sendall(res.encode())
            print(addr,"Top10 req served")
        elif req[0]=='quit':
            print(addr,"connection terminated")
            break
th=threading.Thread(target=cropd)
th.start()

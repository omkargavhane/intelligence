from selenium import webdriver


def top_ten(crop_name):
    res=''
    if crop_name.capitalize() == "Sugarcane":
        crop_name = "sugercane"
    driver = webdriver.Chrome("./chromedriver")
    driver.get("https://www.mapsofindia.com/top-ten/")
    name = driver.find_elements_by_partial_link_text(crop_name.capitalize())[0]
    name.click()
    table = driver.find_elements_by_xpath('//*[@id="content-main"]/div[2]/div[3]/div/div[1]/div[1]/table')
    for tb in table:
        res+=tb.text+''
    driver.close()
    return res





